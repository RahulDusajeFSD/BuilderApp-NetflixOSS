package com.builders.clientDataAccess.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.builders.clientDataAccess.bean.AdminData;
import com.builders.clientDataAccess.repo.AdminDataRepo;

@Service
public class AdminDataService {

	@Autowired
	AdminDataRepo repo;

	public void insertUser(AdminData user) {
	repo.save(user);
	}

	public Iterable<AdminData> getUser() {
		return repo.findAll();
	}


}
