package com.builders.clientDataAccess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.builders.clientDataAccess.bean.AdminData;
import com.builders.clientDataAccess.service.AdminDataService;



@RestController
public class AdminDataController {

	@Autowired
	AdminDataService service;

	@PostMapping("/Rdata")
	void insertUser(@RequestBody AdminData user) {
		service.insertUser(user);
	}

	@GetMapping("/Vdata")
	Iterable<AdminData> getUser() {
		return service.getUser();
	}

//	@GetMapping("/byBHK/{number}")
//	Iterable<AdminData> getPropertyByBHK(@RequestParam Integer number)
//	{
//		return service.getPropertyByBHK(number);
//	}
}
