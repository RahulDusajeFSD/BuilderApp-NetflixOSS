package com.builders.clientDataAccess.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.builders.clientDataAccess.bean.AdminData;


public interface AdminDataRepo extends CrudRepository<AdminData, Integer>{
//	
//	@Query(value="select admindata.data from admindata,admin_info where admindata.pin=admin_info.pin and numBHK=:number;",nativeQuery=true)
//	Iterable<AdminData> getPropertyByBHK(@Param("number") Integer number);

}
