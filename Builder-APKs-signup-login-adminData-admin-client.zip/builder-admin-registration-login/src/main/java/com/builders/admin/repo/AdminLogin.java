package com.builders.admin.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.builders.admin.bean.AdminInfo;

public interface AdminLogin extends CrudRepository<AdminInfo, Integer>{
	
	@Query(value="select admin_info.password from admin_info where admin_info.user_name=:uN and admin_info.pin=:pin", nativeQuery = true)
	String getPassword(@Param("uN") String userName,@Param("pin") Integer pin);

}
