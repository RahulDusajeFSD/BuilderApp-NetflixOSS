package com.builders.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.builders.admin.bean.AdminInfo;
import com.builders.admin.repo.AdminLogin;

@Service
public class AdminLoginService {

	@Autowired
	AdminLogin repo;

	public void insertUser(AdminInfo user) {
		repo.save(user);
	}

	public Iterable<AdminInfo> getUser() {
		return repo.findAll();
	}

	public String validateUser(String userName, Integer pin) {
		return repo.getPassword(userName, pin);

	}

}
