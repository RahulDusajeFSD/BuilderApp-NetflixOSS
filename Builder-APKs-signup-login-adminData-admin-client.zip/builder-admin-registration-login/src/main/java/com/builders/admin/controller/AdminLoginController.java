package com.builders.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.builders.admin.bean.AdminInfo;
import com.builders.admin.service.AdminLoginService;



@RestController
public class AdminLoginController {

	@Autowired
	AdminLoginService service;

	@PostMapping("/Ruser")
	void insertUser(@RequestBody AdminInfo user) {
		service.insertUser(user);
	}

	@GetMapping("/Vuser")
	Iterable<AdminInfo> getUser() {
		return service.getUser();
	}

	@GetMapping("/Vuser/{userName}/{pin}")
	String validateUser(@PathVariable String userName, @PathVariable Integer pin) {
		if (service.validateUser(userName, pin) != null) {
			return "<h1>You've been successfully logged in</h1>";
		}

		return "<h1> Register Yourself </h1>";

	}

//	@GetMapping("/Vuser/{userName}/check")
//	String getVerificationReport(@PathVariable String userName)
//	{
//		if(validateUser(userName))
//			return "<h1>You've been successfully logged in</h1>";
//		
//		return "<h1> Register Yourself </h1>";
//			
//	}

}
