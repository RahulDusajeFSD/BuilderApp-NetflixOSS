package com.builders.client.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.builders.client.bean.ClientInfo;

public interface ClientLogin extends CrudRepository<ClientInfo, Integer>{
	
	@Query(value="select client_info.password from client_info where client_info.user_name=:uN and client_info.pin=:pin", nativeQuery = true)
	String getPassword(@Param("uN") String userName,@Param("pin") Integer pin);

}
