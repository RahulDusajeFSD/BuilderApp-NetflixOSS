package com.builders.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.builders.client.bean.ClientInfo;
import com.builders.client.repo.ClientLogin;

@Service
public class ClientLoginService {

	@Autowired
	ClientLogin repo;

	public void insertUser(ClientInfo user) {
		repo.save(user);
	}

	public Iterable<ClientInfo> getUser() {
		return repo.findAll();
	}

	public String validateUser(String userName, Integer pin) {
		return repo.getPassword(userName, pin);

	}

}
