package com.builders.adminData.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.builders.adminData.bean.AdminData;


public interface AdminDataRepo extends CrudRepository<AdminData, Integer>{
	
	@Query(value="select admin_info.user_name, admin_info.email,admin_info.password from admin_info,admin_data where admin_info.pin=admin_data.pin and admin_data.numbhk=:numBhk",nativeQuery=true)
	String getPropertyByBHK(@Param("numBhk") Integer numBhk);

}
