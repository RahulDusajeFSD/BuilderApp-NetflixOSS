package com.builders.adminData.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AdminData {
	
	@Id
	Integer pin;
	
	Integer numBHK;
	String duplex, lift, garden;
	

	
	public String getDuplex() {
		return duplex;
	}

	public void setDuplex(String duplex) {
		this.duplex = duplex;
	}

	public String getLift() {
		return lift;
	}

	public void setLift(String lift) {
		this.lift = lift;
	}

	public String getGarden() {
		return garden;
	}

	public void setGarden(String garden) {
		this.garden = garden;
	}

	public void setNumBHK(Integer numBHK) {
		this.numBHK = numBHK;
	}

	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Integer getNumBHK() {
		return numBHK;
	}

	

	
	
	
	
	



}
