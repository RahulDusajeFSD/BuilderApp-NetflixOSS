package com.builders.adminData.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.builders.adminData.bean.AdminData;
import com.builders.adminData.service.AdminDataService;



@RestController
public class AdminDataController {

	@Autowired
	AdminDataService service;

	@PostMapping("/Rdata")
	void insertUser(@RequestBody AdminData user) {
		service.insertUser(user);
	}

	@GetMapping("/Vdata")
	Iterable<AdminData> getUser() {
		return service.getUser();
	}
	
	String f="";
	@GetMapping("/byBHK/{numBhk}")
	String getPropertyByBHK(@PathVariable Integer numBhk)
	{
		f=service.getPropertyByBHK(numBhk);
		return f;
	}
}
